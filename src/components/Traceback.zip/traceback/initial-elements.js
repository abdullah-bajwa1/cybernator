import { Position } from "reactflow";
export const nodes = [
  {
    id: '1',
    data: {
      label: 'Node 1',
    },
    position: { x: 300, y: 60 },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: '2',
    data: {
      label: 'Origin',
    },
    position: { x: 0, y: 100 },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: '3',
    data: {
      label: 'Node 2',
    },
    position: { x: 450, y: 180 },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: '6',
    data: {
      label: 'Node 4',
    },
    position: { x: 450, y: -50 },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: '4',
    data: {
      label: 'Node 3',
    },
    position: { x: 600, y: 100 },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  {
    id: '5',
    data: {
      label: 'End',
    },
    position: { x: 850, y: 100 },
    sourcePosition: Position.Right,
    targetPosition: Position.Left,
  },
  
  
];

export const edges = [
  { id: 'e2-1', source: '2', target: '1' },
  { id: 'e2-4', source: '2', target: '4' },
  { id: 'e1-4', source: '1', target: '4' },
  { id: 'e2-6', source: '2', target: '6' },
  { id: 'e6-5', source: '6', target: '5' },
  { id: 'e2-3', source: '2', target: '3', animated: true },
  { id: 'e3-5', source: '3', target: '5', animated: true },
  { id: 'e4-5', source: '4', target: '5', animated: true },
  
];
